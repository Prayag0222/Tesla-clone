import React from 'react'
import Navbar from './components/Navbar/Navbar'

const App = () => {
  return (
    <div className='bg-gray-100 h-screen w-screen'>
      <div>
      <Navbar />
      </div>
    </div>
  )
}

export default App